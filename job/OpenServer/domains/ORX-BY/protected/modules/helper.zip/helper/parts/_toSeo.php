<section class = "l-grid_link">
	<a class = "a-link" href = "<?=Yii::app()->createUrl($url);?>"><?=Yii::t('main', 'View SEO')?></a>
</section>