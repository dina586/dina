<section class = "l-grid_link">
	<a class = "a-link" href = "<?=Yii::app()->createUrl($url);?>"><?=Yii::t('main', 'Move to the list')?></a>
</section>